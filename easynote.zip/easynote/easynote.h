#ifndef EASYNOTE_H
#define EASYNOTE_H

#include <QMainWindow>
#include <QFileDialog>  // 文件对话框
#include <QMessageBox>  //消息盒子
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QFileInfo>
#include <QLineEdit>
#include <QDialog>
#include <QFontDialog>
#include <QLabel>
#include <QSettings>
#include <QDateTime>
#include <windows.h>




QT_BEGIN_NAMESPACE
namespace Ui { class Easynote; }
QT_END_NAMESPACE
class QLineEdit;

class QDialog;

class Easynote : public QMainWindow
{
    Q_OBJECT

public:
    Easynote(QWidget *parent = nullptr);
    ~Easynote();
public slots:
    void newfileSlot(); //创建
    void openFileSlot(); //打开文件
    void saveFileAsSlot(); //另存为
    void saveFileSlot();
    void updatechangeState();

    void UndoSlot();  //撤销
    void cutSlot();   //剪切
    void copySlot();  //复制
    void pastSlot();   //粘贴
    void delateSlot(); //删除

    void allselect();//全选
    void dateSlot();//日期时间

    void charSlot();//字体
    void findhelpSlot();
    void abouteasynote();







public:
    void updateTitle();



private:
    Ui::Easynote *ui;
    bool hasTarget; // 是否有关联文件
    bool isChange;
    QString targetFilePath; // 目标文件的路径
    QString targetFileName; //目标文件名
    QLineEdit *findLineEdit;
    bool statusChecked = true;
    QLabel *lblStatus;


};
#endif // EASYNOTE_H
