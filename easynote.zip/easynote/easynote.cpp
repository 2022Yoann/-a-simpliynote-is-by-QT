#include "easynote.h"
#include "ui_easynote.h"

Easynote::Easynote(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Easynote)
{
    ui->setupUi(this);
    isChange= false;
    hasTarget = false;   //默认无目标
    targetFilePath= "";
    targetFileName = "";
    lblStatus = new QLabel();
    lblStatus->setAlignment(Qt::AlignRight);
    statusBar()->addPermanentWidget(lblStatus);
    updateTitle();
    //文件
    connect(ui->openFileAction,SIGNAL(triggered(bool)),this,SLOT(openFileSlot()));
    connect(ui->newFileAction,SIGNAL(triggered(bool)),this,SLOT(newfileSlot()));
    connect(ui->saveFileAsAction,SIGNAL(triggered(bool)),this,SLOT(saveFileAsSlot()));
    connect(ui->saveFileAction,SIGNAL(triggered(bool)),this,SLOT(saveFileSlot()));
    connect(ui->textEdit,SIGNAL(textChanged()),this,SLOT(updatechangeState()));
    connect(ui->quitAction,SIGNAL(triggered(bool)),this,SLOT(close()));
    //编辑
    connect(ui->backspace,SIGNAL(triggered(bool)),this,SLOT(UndoSlot()));
    connect(ui->cutFile,SIGNAL(triggered(bool)),this,SLOT(cutSlot()));
    connect(ui->copyFiles,SIGNAL(triggered(bool)),this,SLOT(copySlot()));
    connect(ui->filepast,SIGNAL(triggered(bool)),this,SLOT(pastSlot()));
    connect(ui->filedelate,SIGNAL(triggered(bool)),this,SLOT(delateSlot()));
    connect(ui->datetimes,SIGNAL(triggered(bool)),this,SLOT(dateSlot()));

    //格式
    connect(ui->filechar,SIGNAL(triggered(bool)),this,SLOT(charSlot()));
    //帮助
     connect(ui->findhelp,SIGNAL(triggered(bool)),this,SLOT(findhelpSlot()));
     connect(ui->fileabout,SIGNAL(triggered(bool)),this,SLOT(abouteasynote()));
}

Easynote::~Easynote()
{
    delete ui;
}

void Easynote::newfileSlot()
{

    Easynote * newNote  = new Easynote;
    newNote ->show();
}

void Easynote::openFileSlot()
{
    //通过对话框获取含路径文件的文件名
    QString name = QFileDialog::getOpenFileName(this,"打开文件","C:/","文本文件(*.txt);;所有文件(*)");
    if(name.isEmpty())
    {
        QMessageBox::warning(this,"打开文件失败","请选择一个文件");
        return;
    }

    //利用带路径的文件名创建一个文件对象
    QFile targetFile(name);

    if(!targetFile.open(QIODevice::ReadOnly))
    {
         QMessageBox::information(this,"打开文件失败","请选择一个文件");
         return;
    }
  //创建文本流对象，对文件进行读写操作
    QTextStream readStream(&targetFile);
    ui->textEdit->setPlainText(readStream.readAll());
    //更新标题

    hasTarget = true;
    targetFilePath = name;

    QFileInfo info(targetFile);

    targetFileName = info.fileName();
    targetFilePath = info.filePath();

    updateTitle();


}

void Easynote::saveFileAsSlot()
{

     QString  name = QFileDialog:: getSaveFileName(this,"另存为","C:/","文本文件(*.txt);;所有文件(*)");
     if(name.isEmpty())
     {
         QMessageBox::warning(this,"另存文件失败","请重新再试");
         return;

     }
     QFile file(name);
     if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
     {
         QMessageBox::warning(this,"另存文件失败","请重新再试");
         return;
     }
     QTextStream out(&file);
     out << ui->textEdit->toPlainText();

     if(hasTarget == false)
     {
        hasTarget = true;
        QFileInfo info(file);
         targetFileName = info.fileName();
         targetFilePath = info.filePath();
         updateTitle();

     }
     if(!isChange)
     {
        return;
     }
     isChange = false;
      updateTitle();
}

void Easynote::saveFileSlot()
{
    if(!isChange)
    {
        return;
    }
    isChange = false;
    if(hasTarget)
    {
        QFile file(targetFilePath);
        if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QMessageBox::warning(this,"保存文件失败","请重新再试");
            return;
        }
        QTextStream out(&file);
        out << ui->textEdit->toPlainText();
        updateTitle();
        return ;
    }
    saveFileAsSlot();
}

void Easynote::updatechangeState()
{
    if(isChange == false)
    {
        isChange = true;
        updateTitle();
    }

}

void Easynote::UndoSlot()
{
   ui->textEdit->undo();
}

void Easynote::cutSlot()
{
   ui->textEdit->cut();
}

void Easynote::copySlot()
{
   ui->textEdit->copy();
}

void Easynote::pastSlot()
{
    ui->textEdit->paste();
}

void Easynote::delateSlot()
{
   ui->textEdit->textCursor().removeSelectedText();
}

void Easynote::allselect()
{
     ui->textEdit->selectAll();
}

void Easynote::dateSlot()
{
    QString dateTime = QDateTime::currentDateTime().toString(Qt::SystemLocaleDate);
    ui->textEdit->textCursor().insertText(dateTime);
}


void Easynote::charSlot()
{
    bool ok;
    QFont font = QFontDialog::getFont(&ok, ui->textEdit->font());
    if (ok)
        ui->textEdit->setFont(font);
}


void Easynote::findhelpSlot()
{
     QMessageBox::warning(this, tr("提示"), tr("有问题找百度"), tr("确定"));
}

void Easynote::abouteasynote()
{

    QString appPath = QApplication::applicationFilePath();
    HICON icon = ExtractIcon(NULL, appPath.toStdWString().c_str(), 0);
    ShellAbout((HWND)this->winId(), tr("Qt记事本").toStdWString().c_str(), tr("作者：yyx").toStdWString().c_str(), icon);
}

void Easynote::updateTitle()
{
    QString str;

    if(hasTarget)
    {
        str = targetFileName +"- yyx的文本编辑器";

    }
    else
    {
        str = "无标题 - yyx的文本编辑器";
    }
    if(isChange)
    {
        str += " *";
    }
    this->setWindowTitle(str);

}






